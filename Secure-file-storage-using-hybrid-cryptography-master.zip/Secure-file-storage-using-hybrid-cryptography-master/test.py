from cryptography.fernet import Fernet
import os

